import { CharStream, CommonTokenStream } from "antlr4ng";
import { SmaliLexer } from "./lib/SmaliLexer.js";
import { ParseContext, SmaliParser } from "./lib/SmaliParser.js";
import { SmaliWriter } from "./lib/SmaliWriter.js";

function addTestMethodToClass(ctx: ParseContext) {
	const lexer = new SmaliLexer(
		CharStream.fromString(
			`.method public static test()V
		return-void
.end method`
		)
	);
	const tokens = new CommonTokenStream(lexer);
	const parser = new SmaliParser(tokens);
	const method = parser.methodDirective();

	method.parent = ctx;
	ctx.children.push(method);
}

const lexer = new SmaliLexer(
	CharStream.fromString(
		`.class public LHelloWorld;
.super Ljava/lang/Object;

.method public static main([Ljava/lang/String;)V
    .registers 2

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string	v1, "Hello World!"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method
`
	)
);
const tokens = new CommonTokenStream(lexer);
const parser = new SmaliParser(tokens);
const tree = parser.parse();

addTestMethodToClass(tree);
SmaliWriter.write(tree);
